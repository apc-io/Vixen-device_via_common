#define LOG_TAG "BatteryService"

#ifndef BATTERY_H_
#define BATTERY_H_

#include <utils/Thread.h>
#include <cutils/log.h>
//#include <android_runtime/AndroidRuntime.h>
using namespace android;

class BatteryThread: public Thread {
    typedef void (*Timerfunc)(int res);
    typedef Timerfunc TimerHandler;

public:
    virtual bool batt_init();
    virtual void batt_deinit();
    virtual void batt_update(int* result);
	
	BatteryThread();
	virtual  ~BatteryThread() ;
	bool threadLoop();
	void registerHandler(TimerHandler handler);
	void setInterval(int second);
  
   

private:
    bool m_loop;
    unsigned long m_interval; //millisecond
    TimerHandler m_handler;
    int m_parameter;
};

#endif /* BATTERY_H_ */

// vim: et ts=4 shiftwidth=4
